This App was ported to HRCloud2 by zelon88 on 12/21/2016.
https://github.com/zelon88
https://github.com/zelon88/HRCloud2

The original author is Github user  "avignat"
https://github.com/avignat
The original Github repo was  "Check-Server-Status"
https://github.com/avignat/Check-Server-Status
=========================================================

# Check Server Status

PHP Script that check if a server is online or not.

## Installation
- Clone this repo in your web folder.
- Add your servers in the servers.xml file.

Example :

```
<servers>
	<server id="42">
		<name>Home Server</name>
		<host>myserver.com</host>
		<port>80</port>
	</server>
</servers>
``` 
- Access the ServStat.php page.
## Screenshot
![Main](https://github.com/p1rox/Check-Server-Status/raw/master/img/main.png)