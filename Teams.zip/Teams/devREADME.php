<?php

// / Current user status is parsed from the cache file variable...
//$USER_STATUS
// / ...and read to...
//$currentUserStatus 
// / ...as needed.

// / List of valid User Status...
// 0 = Not logged in
// 1 = Logged in
// 2 = Away (Auto)
// 3 = Away (User Specified)
// 4 = Busy

// / Current user team status is parsed from the cache file variable...
//currentTeamStatus
// / ...and read to an array of Team ID's that the user is logged into.
//$currentTeamStatus 
// / ...as needed.

// / List of valid User Team Status...
// array($TeamID1, $TeamID1, $TeamID3)

?>