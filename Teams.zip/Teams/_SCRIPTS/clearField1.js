// / Javascript to clear the messenger text input field onclick.
    function Clear0() {    
      document.getElementById("messangerInput").value= ""; }
      
// / Javascript to clear the new Team name text input field onclick.
    function Clear1() {    
      document.getElementById("newTeam").value= ""; }

// / Javascript to clear the new Team description text input field onclick.
    function Clear2() {    
      document.getElementById("teamDescription").value= ""; }