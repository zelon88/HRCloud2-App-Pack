<?php

// / This is the Readme file for the HRCloud2 Notes App.
// / 
// / All HRCloud2 apps require a README.php file with basic
// / information about the app.
// / 
// / You can use this file as a guide to writing your own
// / HRCloud2 App!

/*//
HRCLOUD2-PLUGIN-START
App Name: Notes
App Version: 1.0 
App License: GPLv3
App Author: zelon88
App Description: A simple HRCloud2 app for creating, viewing, and managing notes and to-do lists!
App Integration: 1 (True)
HRCLOUD2-PLUGIN-END
//*/
