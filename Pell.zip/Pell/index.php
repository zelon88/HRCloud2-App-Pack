<!DOCTYPE html>
<title>HRCloud2 | Cloud Authentication</title>
<html lang="en-US">
<html>
<body>
<div id="outer" align="center"><h1>Configuring your Cloud Drive ...</h1>
<?php require($InstLoc.'/config.php'); ?>

<div id="inner" style="position:absolute; top:50%; left:50%; height:10em; margin-top:-5em; margin-right:5em;"><strong>Please wait . . .</strong></div>
</div>
<script type="text/javascript">
// Set the URL below to the page the user is sent to if their screensize is UNDER the specified number of pixels.
if (screen.width <= 699) { document.location = "/HRProprietary/HRCloud2/index0.php"; }
// / Set the URL below to the page the user is sent to if their screensize is OVER the specified number of pixels.
if (screen.width >= 700) { document.location = "/HRProprietary/HRCloud2/index1.php"; }
// Iphone page.
if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPhone/i))) {
   location.replace("/HRProprietary/HRCloud2/index0.php"); }
// Ipod page.
if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i))) {
   location.replace("/HRProprietary/HRCloud2/index0.php"); }
// Ipad Page.
if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPad/i))) {
   location.replace("/HRProprietary/HRCloud2/index0.php"); }
</script>

<meta id="IfNothingHappens" http-equiv="refresh" content="5"; url="/HRProprietary/HRCloud2/index1.php" >

</body>
</html>
