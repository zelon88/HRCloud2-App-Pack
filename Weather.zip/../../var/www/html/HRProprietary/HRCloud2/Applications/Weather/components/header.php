<!DOCTYPE html>
<html>
<head>
	<title>Weather App</title>

	  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" integrity="sha384-y3tfxAZXuh4HwSYylfB+J125MxIs6mR5FOHamPBG064zB+AFeWH94NdvaCBm8qnd" crossorigin="anonymous">
     <!-- Weather Icon Fonts -->
		<link rel="stylesheet" href="assets/css/weather-icons.min.css">
		<link rel="stylesheet" type="text/css" href="assets/css/styles.css">



</head>
<body>
