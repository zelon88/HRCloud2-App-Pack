# PHP__Weather__App

A simple weather app using php and Bootstrap for the front end.

This project was created as part of an exercise while I was learning the basics of PHP. 
I used PHP and Bootstrap to retrieve a weather forecast for a given location from weather-forecast.com. 

User gets a 1-3 day forecast, followed by a 4-7 day forecast and a 7-10 day forecast
which are displayed in three consecutive sections; local time for the requested city is also displayed.

### API - Work In Progress

```
Code at the moment is being refactored to use an API instead of scraping web content. The live version still 
uses the old code.
```

