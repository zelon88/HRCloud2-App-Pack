<?php

/*//
HRCLOUD2-PLUGIN-START
App Name: Weather
App Version: v0.7 (4-13-2021 00:00)
App License: GPLv3
App Author: lannes & zelon88
App Description: A simple HRCloud2 Weather app.
App Integration: 0 (False)
App Permission: 1 (Everyone)
HRCLOUD2-PLUGIN-END
//*/

include 'components/header.php';

include 'components/content.php';

include 'components/footer.php';