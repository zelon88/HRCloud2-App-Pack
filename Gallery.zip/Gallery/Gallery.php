<?php

/*//
HRCLOUD2-PLUGIN-START
App Name: Gallery
App Version: 1.1 (11-29-2016 23:15)
App License: GPLv3
App Author: zelon88
App Description: A simple HRCloud2 App for viewing/organizing pictures.
App Integration: 0 (False)
HRCLOUD2-PLUGIN-END
//*/

// / Credits to Itzik Gur and IconArchive.com for the cool Photograph+Camera icon! 
// / http://www.iconarchive.com/show/my-seven-icons-by-itzikgur/Pictures-Canon-icon.html
?>
<script src="sorttable.js"></script>
<script type="text/javascript">
// / Javascript to clear the newNote text input field onclick.
    function Clear() {    
      document.getElementById("galleryInput").value= ""; }
</script>
<div id='GalleryAPP' name='GalleryAPP' align='center'><h3>Gallery</h3><hr />
<form action="Gallery.php" method="post">
<input id="galleryInput" name="galleryInput" value="" type="text">
<input type="submit" id="gallerySubmit" name="gallerySubmit" title="Perform Equation" alt="Perform Equation" value="Perform Equation"></form>
<hr />
<?php

// / The follwoing code checks if the securityCore.php file exists and 
// / terminates if it does not.
if (!file_exists('/var/www/html/HRProprietary/HRCloud2/securityCore.php')) {
  echo nl2br('</head><body>ERROR!!! HRC2GalleryApp30, Cannot process the HRCloud2 Security Core file (securityCore.php)!'."\n".'</body></html>'); 
  die (); }
else {
  require_once ('/var/www/html/HRProprietary/HRCloud2/securityCore.php'); }

