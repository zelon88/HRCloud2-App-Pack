<!DOCTYPE HTML>
<?php
    $feeds = array(
        "http://maxburstein.com/rss",
        "http://www.engadget.com/rss.xml",
        "http://www.reddit.com/r/programming/.rss"
    );
 