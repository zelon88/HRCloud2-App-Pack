Cooling 0: Processor 0 of 10   ,   Cooling 1: Processor 0 of 10   ,   Cooling 2: Processor 0 of 10   ,   Cooling 3: Processor 0 of 10   ,   Cooling 4: Processor 0 of 10   ,   Cooling 5: Processor 0 of 10   ,   Cooling 6: Processor 0 of 10   ,   Cooling 7: Processor 0 of 10



