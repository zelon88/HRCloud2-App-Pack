Cooling 0: Processor 0 of 10   ,   Cooling 1: Processor 0 of 10   ,   Cooling 2: Processor 0 of 10   ,   Cooling 3: Processor 0 of 10   ,   Cooling 4: Processor 0 of 10   ,   Cooling 5: Processor 0 of 10   ,   Cooling 6: Processor 0 of 10   ,   Cooling 7: Processor 0 of 10   ,   Cooling 8: Processor 0 of 10   ,   Cooling 9: Processor 0 of 10   ,   Cooling 10: Processor 0 of 10   ,   Cooling 11: Processor 0 of 10   ,   Cooling 12: Processor 0 of 10   ,   Cooling 13: Processor 0 of 10   ,   Cooling 14: Processor 0 of 10   ,   Cooling 15: Processor 0 of 10



