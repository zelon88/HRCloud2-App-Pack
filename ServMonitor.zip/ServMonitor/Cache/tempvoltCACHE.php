Cooling 0: Processor 0 of 7   ,   Cooling 1: Processor 0 of 7   ,   Cooling 2: Processor 0 of 7   ,   Cooling 3: Processor 0 of 7   ,   Cooling 4: Processor 0 of 7   ,   Cooling 5: Processor 0 of 7   ,   Cooling 6: Processor 0 of 7   ,   Cooling 7: Processor 0 of 7



