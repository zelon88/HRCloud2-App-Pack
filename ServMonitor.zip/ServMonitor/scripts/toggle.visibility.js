    function toggle_visibility(id) {
      var e = document.getElementById(id);
      if(e.style.display == 'none')
         e.style.display = 'block';
      else
         e.style.display = 'none'; }
    function toggle_visibility1(id) {
      var e = document.getElementById(id);
      if(e.style.display == 'none')
         e.style.display = 'block';
      else
         e.style.display = 'none'; }
    function toggle_visibilitySHOW(id) {
      var e = document.getElementById(id);
      if(e.style.display == 'none')
         e.style.display = 'block';
      else
         e.style.display = 'block'; }
    function toggle_visibilityHIDE(id) {
      var e = document.getElementById(id);
      if(e.style.display == 'block')
         e.style.display = 'none';
      else
         e.style.display = 'none'; }